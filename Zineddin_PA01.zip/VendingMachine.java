/*
 * ***************************************
 * CIS611				Spring 2021					Ahmad Zineddin	
 * 
 * 					Programming Assignment PA01
 * 
 * 				Class: TaxCalculation
 * 				Purpose: To allow a user to enter their income and
 * 				marital status which then calculates their federal
 * 				personal income tax.
 * 
 * 					Date Created: February 9, 2021
 * ***************************************
 */
import javax.swing.JOptionPane;

public class VendingMachine 
{

	public static void main(String[] args) 
	{
		String itemName = new String();
		double itemPrice = 0;
		String insertBill = new String();
		double billValue;
		double balancePrice;
		int tryAgain = JOptionPane.YES_OPTION;
		while (tryAgain == 0)
		{
			itemName = JOptionPane.showInputDialog("Vending Machine Options:\n" + 
										"1. Trail Mix \t $1.25\n" + 
										"2. Snickers \t $2.00\n" +
										"3. Chewing Gum \t $0.50\n" +
										"4. Cheetos \t $5.75");
			if (itemName != null)
			{
				switch (itemName)
				{
					case ("1"):
						itemPrice = 1.25;
						itemName = "Trail Mix";
						break;
					case ("2"):
						itemPrice = 2.00;
						itemName = "Snickers";
						break;
					case ("3"):
						itemPrice = 0.50;
						itemName = "Chewing Gum";
						break;
					case ("4"):
						itemPrice = 5.75;
						itemName = "Cheetos";
						break;
					default:
						JOptionPane.showMessageDialog(null, "You entered: " + itemName + "\nNot a valid option! Please try again.");
				}
			}
			else 
				System.exit(0);
			
			insertBill = JOptionPane.showInputDialog("Please insert money for " + itemName +
													"\nThe cost is $" + itemPrice + "." +
													" This machine only accepts $1, $5, and $10 bills, \n" +
													"and only one of these bills at a time for each purchase." +
													"\nCards and coins are not accepted.");
			
			if (insertBill.equals(""))
			{
				JOptionPane.showMessageDialog(null, "Nothing entered! Please try again.");
				continue;
			}
			
			billValue = Double.parseDouble(insertBill);
			
			if (billValue == 1 || billValue == 5 || billValue == 10)
			{
				if (billValue < itemPrice)
				{
					JOptionPane.showMessageDialog(null, "Not enough to complete purchase! Please enter a higher bill.");
					continue;
				}
				else
				{
					balancePrice = billValue - itemPrice;
					int fives = 0;
					int ones = 0;
					int halves = 0;
					int quarters = 0;
					if (balancePrice >= 5) 
					{ 
					    fives = (int) (balancePrice / 5); 
					    balancePrice -= 5;
					}

					if (balancePrice < 5 && balancePrice >= 1) 
					{ 
					    ones = (int) (balancePrice / 1); 
					    balancePrice -= ones; }

					if (balancePrice < 1 && balancePrice >= 0.5) 
					{ 
					    halves = (int) (balancePrice / 0.5);
					    balancePrice -= 0.5;
					    }

					if (balancePrice < 0.5 && balancePrice >= 0.25) 
					{
					    quarters = (int) (balancePrice / 0.25);
					    balancePrice = 0;
					}
					
					JOptionPane.showMessageDialog(null, "You selected item number " + itemName + "which is " + itemName +
												 "\n\nCost of " + itemName + " is " + itemPrice +
												 "\nYou inserted " + billValue + 
												 "\nYour balance is " + balancePrice +
												 "\nYour change is: " + "\n\t\t" + fives + " * $5 \n\t\t" + ones + " * $1 \n\t\t" + halves + " * $0.50 \n\t\t" + quarters + " * $0.25 \n\t\t");
				}
					
			}
			else
			{
				JOptionPane.showMessageDialog(null, "Invalid bill entered! Please try again.");
				continue;
			}
			System.exit(0);
		}
			
	}

}
